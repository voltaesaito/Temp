<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use Illuminate\Support\Facades\DB;
use Illuminate\Database;
class Listings extends Model
{
    //
    protected $table = 'listings';
}
